self.addEventListener('install', function (event) {
    var indexPage = new Request('index.html');
    event.waitUntil(
        fetch(indexPage).then(function (response) {
            caches.open('pwabuilder-offline').then(function (cache) {
                console.log('[PWA Builder] Cached index page during Install' + response.url);
                return cache.addAll(['/index.html',
                    '/404.html', 
                    '/bomboniere.html', 
                    '/contato.html', 
                    '/informacoes.html',
                    '/locacao.html',
                    '/login.html',
                    '/ingressos.html',
                    '/manifest.json',
                    '/programacao.html',
                    '/registrarSe1.html',
                    '/registrarSe2.html',
                    '/registrarSe3.html',
                    '/registrarSe5.html',
                    '/css/design.css',
                    '/js/firebase.js',
                    '/js/materialize.min.js',
                    '/js/nextRegisterPage.js',
                    '/js/programacao.js',
                    '/js/registerPage1.js',
                    '/js/registerPage3.js',
                    '/js/registerPageSwap.js',
                    '/img/1balck.png',
                    '/img/1red.png',
                    '/img/2black.png',
                    '/img/2red.png',
                    '/img/3black.png',
                    '/img/3red.png',
                    '/img/4black.png',
                    '/img/4red.png',
                    '/img/5black.png',
                    '/img/5red.png',
                    '/img/12.jpg',
                    '/img/16.jpg',
                    '/img/accountDefault.png',
                    '/img/americanExpress.png',
                    '/img/blackPanther.jpg',
                    '/img/bP1.jpg',
                    '/img/bP2.jpg',
                    '/img/bP3.jpg',
                    '/img/bP4.jpg',
                    '/img/candy.png',
                    '/img/cardCode.png',
                    '/img/check.png',
                    '/img/enzo.png',
                    '/img/estrelas.png',
                    '/img/hipercard.png',
                    '/img/infoHelp.png',
                    '/img/livre.jpg',
                    '/img/classifica.jpg',
                    '/img/masterCard.png',
                    '/img/meeting.png',
                    '/img/pedro.png',
                    '/img/popcorn.png',
                    '/img/shape1.jpg',
                    '/img/shape2.jpg',
                    '/img/shape3.jpg',
                    '/img/shape4.jpg',
                    '/img/shapeWater.jpg',
                    '/img/soda.png',
                    '/img/subway.jpg',
                    '/img/ticket.png',
                    '/img/visa.png',
                    '/img/viva.jpg',
                    '/img/viva1.jpg',
                    '/img/viva2.jpg',
                    '/img/viva3.jpg',
                    '/img/viva4.jpg',
                    '/img/windowIcon.png',
                    '/img/icons/icon-72x72.png',
                    '/img/icons/icon-96x96.png',
                    '/img/icons/icon-128x128.png',
                    '/img/icons/icon-144x144.png',
                    '/img/icons/icon-152x152.png',
                    '/img/icons/icon-192x192.png',
                    '/img/icons/icon-384x384.png',
                    '/img/icons/icon-512x512.png'
                ]);
            });
        })
    );
});


//If any fetch fails, it will look for the request in the cache and serve it from there first
self.addEventListener('fetch', function (event) {
    var updateCache = function (request) {
        return caches.open('pwabuilder-offline').then(function (cache) {
            return fetch(request).then(function (response) {
                console.log('[PWA Builder] add page to offline' + response.url)
                return cache.put(request, response);
            });
        });
    };

    event.waitUntil(updateCache(event.request));

    event.respondWith(
        fetch(event.request).catch(function (error) {
            console.log('[PWA Builder] Network request Failed. Serving content from cache: ' + error);

            //Check to see if you have it in the cache
            //Return response
            //If not in the cache, then return error page
            return caches.open('pwabuilder-offline').then(function (cache) {
                return cache.match(event.request).then(function (matching) {
                    var report = !matching || matching.status == 404 ? Promise.reject('no-match') : matching;
                    return report
                });
            });
        })
    );
})