// Initialize Firebase
// TODO: Replace with your project's customized code snippet
var config = {apiKey: "<API_KEY>",authDomain:"cine-dunas.firebaseapp.com",databaseURL:"https://cine-dunas.firebaseio.com",storageBucket: "cine-dunas.appspot.com",};firebase.initializeApp(config);