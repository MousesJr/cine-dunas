$(function(){
    $(".button-collapse").sideNav();
});